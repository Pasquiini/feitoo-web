<?php



namespace App\Services;



use Carbon\Carbon;

use Illuminate\Support\Collection;

use Illuminate\Support\Facades\DB;

use InvalidArgumentException;



class ClonagemEscalasService

{

    private function empresaId(): int
    {
        $usuario = auth()->user();
        $empresaId = $usuario && $usuario->pessoa && $usuario->pessoa->profissional
            ? (int) $usuario->pessoa->profissional->empresa_id
            : 0;

        if ($empresaId <= 0) {
            throw new InvalidArgumentException('Empresa do usuário não identificada.');
        }

        return $empresaId;
    }

    public function preview(array $dados): array

    {

        $origem = $this->obterMes(

            $dados['mes_origem'] ?? null

        );



        $destino = isset($dados['mes_destino'])

            ? $this->obterMes($dados['mes_destino'])

            : $origem->copy()->addMonthNoOverflow();



        if (!$destino->isSameMonth(

            $origem->copy()->addMonthNoOverflow()

        )) {

            throw new InvalidArgumentException(

                'O destino deve ser o mês seguinte ao de origem.'

            );

        }



        $modalidade = $dados['modalidade'] ?? 'todos';



        if (!in_array(

            $modalidade,

            ['enfermagem', 'multi', 'todos'],

            true

        )) {

            throw new InvalidArgumentException(

                'Modalidade de clonagem inválida.'

            );

        }



        $filtros = $dados['filtros'] ?? [];



        if (!is_array($filtros)) {

            throw new InvalidArgumentException(

                'Os filtros devem ser um objeto.'

            );

        }



        $contratoId = !empty($dados['contract_id'])

            ? (int) $dados['contract_id']

            : null;



        $escalas = $this->buscarEscalasOrigem(

            $origem,

            $modalidade,

            $contratoId,

            $filtros

        );



        $avisos = [];

        $propostas = [];



        foreach ($escalas as $escala) {

            $calculada = $this->projetarEscala(

                $escala,

                $destino,

                $avisos

            );



            if ($calculada !== null) {

                $propostas[] = $calculada;

            }

        }



        $existentes = $this->buscarEscalasDestino($destino);



        $this->identificarDuplicidades(

            $propostas,

            $existentes,

            $avisos

        );



        $contratos = collect($propostas)

            ->pluck('contract_id')

            ->filter()

            ->unique()

            ->values()

            ->all();



        $orcamentos = $this->buscarQuantidadesOrcamento(

            $contratos

        );



        $servicos = $this->compararOrcamento(

            $propostas,

            $orcamentos

        );



        $this->adicionarAvisosOrcamento(

            $servicos,

            $avisos

        );



        $calendario = collect($propostas)

            ->groupBy(function ($item) {

                return substr($item['dataentrada'], 0, 10);

            })

            ->map(function ($itens, $data) {

                return [

                    'data' => $data,

                    'quantidade' => $itens->count(),

                    'escalas' => $itens->values()->all(),

                ];

            })

            ->values()

            ->all();



        return [

            'mes_origem' => $origem->format('Y-m'),

            'mes_destino' => $destino->format('Y-m'),

            'modalidade' => $modalidade,

            'empresa_id' => $this->empresaId(),

            'filtros_aplicados' => $filtros,

            'contract_id' => $contratoId,

            'resumo' => [

                'escalas_origem' => $escalas->count(),

                'escalas_propostas' => count($propostas),

                'conflitos' => collect($propostas)

                    ->where('conflito', true)

                    ->count(),

                'nao_projetadas' =>

                $escalas->count() - count($propostas),

            ],

            'servicos' => $servicos,

            'calendario' => $calendario,

            'propostas' => $propostas,

            'avisos' => $avisos,

        ];

    }



    private function obterMes($valor): Carbon

    {

        if (

            !is_string($valor) ||

            !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $valor)

        ) {

            throw new InvalidArgumentException(

                'O mês deve estar no formato YYYY-MM.'

            );

        }



        return Carbon::createFromFormat(

            '!Y-m-d',

            $valor . '-01'

        )->startOfDay();

    }



    private function buscarEscalasOrigem(

        Carbon $mes,

        string $modalidade,

        ?int $contratoId,

        array $filtros

    ): Collection {

        $query = DB::table('escalas as e')

            ->join('ml_contracts as c', 'c.id', '=', 'e.contract_id')

            ->leftJoin(

                'prestadores as pr',

                'pr.id',

                '=',

                'e.prestador_id'

            )

            ->leftJoin(

                'pessoas as pp',

                'pp.id',

                '=',

                'pr.pessoa_id'

            )

            ->leftJoin(

                'pacientes as pa',

                'pa.id',

                '=',

                'e.paciente_id'

            )

            ->leftJoin(

                'pessoas as pc',

                'pc.id',

                '=',

                'pa.pessoa_id'

            )

            ->leftJoin(

                'servicos as s',

                's.id',

                '=',

                'e.servico_id'

            )

            ->where('e.empresa_id', $this->empresaId())

            ->where('e.ativo', 1)

            ->whereNotNull('e.contract_id')

            ->where('c.company_id', $this->empresaId())

            ->whereBetween('e.dataentrada', [

                $mes->copy()->startOfMonth()->format('Y-m-d H:i:s'),

                $mes->copy()->endOfMonth()->format('Y-m-d H:i:s'),

            ])

            ->select([

                'e.*',

                'pp.nome as nome_prestador',

                'pc.nome as nome_paciente',

                's.descricao as nome_servico',

                'c.budget_id',

            ]);



        if ($contratoId) {

            $query->where('e.contract_id', $contratoId);

        }



        if ($modalidade === 'enfermagem') {

            $query->where('e.tipo', 'Plantão');

        }



        if ($modalidade === 'multi') {

            $query->where('e.tipo', '<>', 'Plantão');

        }



        if (!empty($filtros['busca'])) {

            $busca = '%' . trim($filtros['busca']) . '%';



            $query->where(function ($q) use ($busca) {

                $q->where('pp.nome', 'like', $busca)

                    ->orWhere('pc.nome', 'like', $busca);

            });

        }



        if (!empty($filtros['servico'])) {

            $query->where(

                's.descricao',

                $filtros['servico']

            );

        }



        if (!empty($filtros['periodo'])) {

            $query->where(

                'e.periodo',

                $filtros['periodo']

            );

        }



        if (!empty($filtros['tipo'])) {

            $query->where('e.tipo', $filtros['tipo']);

        }



        if (($filtros['situacao'] ?? '') === 'internado') {

            $query->where('c.disable_motive', 'Internado');

        }



        if (($filtros['situacao'] ?? '') === 'folga') {

            $query->where('e.folga', 1);

        }



        if (($filtros['situacao'] ?? '') === 'normal') {

            $query->where(function ($q) {

                $q->whereNull('e.folga')

                    ->orWhere('e.folga', 0);

            });

        }



        return $query

            ->orderBy('e.dataentrada')

            ->orderBy('e.id')

            ->get();

    }



    private function projetarEscala(

        object $escala,

        Carbon $destino,

        array &$avisos

    ): ?array {

        if (!$escala->dataentrada || !$escala->datasaida) {

            $avisos[] = [

                'tipo' => 'dados_incompletos',

                'escala_id' => $escala->id,

                'mensagem' => 'Escala sem entrada ou saída válida.',

            ];



            return null;

        }



        $entrada = Carbon::parse($escala->dataentrada);

        $saida = Carbon::parse($escala->datasaida);



        if ($saida->lessThanOrEqualTo($entrada)) {

            $avisos[] = [

                'tipo' => 'duracao_invalida',

                'escala_id' => $escala->id,

                'mensagem' => 'A saída precisa ser posterior à entrada.',

            ];



            return null;

        }



        if ($escala->tipo === 'Plantão') {

            $dia = $entrada->day;



            if ($dia > $destino->daysInMonth) {

                $avisos[] = [

                    'tipo' => 'dia_inexistente',

                    'escala_id' => $escala->id,

                    'data_origem' => $entrada->format('Y-m-d'),

                    'mensagem' =>

                    'O dia ' . $dia .

                        ' não existe no mês de destino.',

                ];



                return null;

            }



            $novaEntrada = $destino->copy()

                ->day($dia)

                ->setTime(

                    $entrada->hour,

                    $entrada->minute,

                    $entrada->second

                );

        } else {

            $novaEntrada = $this->projetarMesmoDiaSemana(

                $entrada,

                $destino,

                $avisos,

                (int) $escala->id

            );

        }



        $duracaoSegundos = $entrada->diffInSeconds($saida);



        $novaSaida = $novaEntrada->copy()

            ->addSeconds($duracaoSegundos);



        return [

            'escala_origem_id' => (int) $escala->id,

            'empresa_id' => $this->empresaId(),

            'contract_id' => (int) $escala->contract_id,

            'paciente_id' => $escala->paciente_id,

            'prestador_id' => $escala->prestador_id,

            'prestador_proprietario' =>

            $escala->prestador_proprietario,

            'cooperative_id' => $escala->cooperative_id,

            'servico_id' => $escala->servico_id,

            'formacao_id' => $escala->formacao_id,

            'prestador' => $escala->nome_prestador,

            'paciente' => $escala->nome_paciente,

            'servico' => $escala->nome_servico,

            'tipo' => $escala->tipo,

            'periodo' => $escala->periodo,

            'dataentrada' =>

            $novaEntrada->format('Y-m-d H:i:s'),

            'datasaida' =>

            $novaSaida->format('Y-m-d H:i:s'),

            'horaentrada' =>

            $novaEntrada->format('H:i'),

            'horasaida' =>

            $novaSaida->format('H:i'),

            'folga' => (bool) $escala->folga,

            'observacao' => $escala->observacao,

            'conflito' => false,

            'motivos_conflito' => [],

        ];

    }

    private function projetarMesmoDiaSemana(

        Carbon $original,

        Carbon $destino,

        array &$avisos,

        int $escalaId

    ): Carbon {

        $ocorrencia = (int) ceil($original->day / 7);



        $primeiroDia = $destino->copy()->startOfMonth();



        $diferenca = (

            $original->dayOfWeek -

            $primeiroDia->dayOfWeek + 7

        ) % 7;



        $dia = 1 + $diferenca + (($ocorrencia - 1) * 7);



        if ($dia > $destino->daysInMonth) {

            $dia -= 7;



            $avisos[] = [

                'tipo' => 'ocorrencia_indisponivel',

                'escala_id' => $escalaId,

                'mensagem' =>

                'A ocorrência semanal não existe no destino. ' .

                    'Foi sugerida a última ocorrência do mesmo dia.',

            ];

        }



        return $destino->copy()

            ->day($dia)

            ->setTime(

                $original->hour,

                $original->minute,

                $original->second

            );

    }



    private function buscarEscalasDestino(

        Carbon $destino

    ): Collection {

        $inicio = $destino->copy()->startOfMonth();

        $fim = $destino->copy()->endOfMonth();



        return DB::table('escalas')

            ->where('empresa_id', $this->empresaId())

            ->where('ativo', 1)

            ->whereNotNull('dataentrada')

            ->whereNotNull('datasaida')

            ->where('dataentrada', '<=', $fim->format('Y-m-d H:i:s'))

            ->where('datasaida', '>', $inicio->format('Y-m-d H:i:s'))

            ->select([

                'id',

                'contract_id',

                'paciente_id',

                'prestador_id',

                'prestador_proprietario',

                'servico_id',

                'tipo',

                'dataentrada',

                'datasaida',

            ])

            ->orderBy('dataentrada')

            ->get();

    }



    private function chaveEscala($escala): string

    {

        $valor = function ($campo) use ($escala) {

            if (is_array($escala)) {

                return $escala[$campo] ?? '';

            }



            return $escala->{$campo} ?? '';

        };



        return implode('|', [

            $valor('contract_id'),

            $valor('prestador_id'),

            $valor('servico_id'),

            $valor('tipo'),

            $valor('dataentrada'),

        ]);

    }



    private function identificarDuplicidades(

        array &$propostas,

        Collection $existentes,

        array &$avisos

    ): void {

        $chavesExistentes = [];



        foreach ($existentes as $existente) {

            $chave = $this->chaveEscala($existente);



            if (!isset($chavesExistentes[$chave])) {

                $chavesExistentes[$chave] = [];

            }



            $chavesExistentes[$chave][] = (int) $existente->id;

        }



        $gruposPropostas = [];



        foreach ($propostas as $index => $proposta) {

            $chave = $this->chaveEscala($proposta);

            $gruposPropostas[$chave][] = $index;



            $propostas[$index]['conflito'] = false;

            $propostas[$index]['motivos_conflito'] = [];

            $propostas[$index]['tipos_conflito'] = [];

        }



        foreach ($gruposPropostas as $chave => $indices) {

            $idsExistentes = $chavesExistentes[$chave] ?? [];



            if (!empty($idsExistentes)) {

                foreach ($indices as $index) {

                    $this->adicionarConflito(

                        $propostas,

                        $index,

                        'duplicidade_destino',

                        'Esta escala já está cadastrada no mês de destino.'

                    );

                }

            }



            if (count($indices) > 1) {

                foreach ($indices as $index) {

                    $this->adicionarConflito(

                        $propostas,

                        $index,

                        'duplicidade_proposta',

                        'Existem outras propostas com os mesmos dados.'

                    );

                }

            }

        }



        $total = count($propostas);



        for ($i = 0; $i < $total; $i++) {

            for ($j = $i + 1; $j < $total; $j++) {

                $primeira = $propostas[$i];

                $segunda = $propostas[$j];



                if (

                    empty($primeira['prestador_id']) ||

                    empty($segunda['prestador_id'])

                ) {

                    continue;

                }



                if (

                    (int) $primeira['prestador_id'] !==

                    (int) $segunda['prestador_id']

                ) {

                    continue;

                }



                if (!$this->horariosSobrepostos(

                    $primeira['dataentrada'],

                    $primeira['datasaida'],

                    $segunda['dataentrada'],

                    $segunda['datasaida']

                )) {

                    continue;

                }



                if (

                    $this->chaveEscala($primeira) ===

                    $this->chaveEscala($segunda)

                ) {

                    continue;

                }



                $mensagemPrimeira = sprintf(

                    'O profissional também está previsto na escala de origem #%d, contrato #%d, no mesmo horário.',

                    $segunda['escala_origem_id'],

                    $segunda['contract_id']

                );



                $mensagemSegunda = sprintf(

                    'O profissional também está previsto na escala de origem #%d, contrato #%d, no mesmo horário.',

                    $primeira['escala_origem_id'],

                    $primeira['contract_id']

                );



                $this->adicionarConflito(

                    $propostas,

                    $i,

                    'sobreposicao_proposta',

                    $mensagemPrimeira

                );



                $this->adicionarConflito(

                    $propostas,

                    $j,

                    'sobreposicao_proposta',

                    $mensagemSegunda

                );

            }

        }



        foreach ($propostas as $index => $proposta) {

            if (empty($proposta['prestador_id'])) {

                continue;

            }



            foreach ($existentes as $existente) {

                if (

                    !$existente->prestador_id ||

                    (int) $existente->prestador_id !==

                    (int) $proposta['prestador_id']

                ) {

                    continue;

                }



                if (!$this->horariosSobrepostos(

                    $proposta['dataentrada'],

                    $proposta['datasaida'],

                    $existente->dataentrada,

                    $existente->datasaida

                )) {

                    continue;

                }



                if (

                    $this->chaveEscala($proposta) ===

                    $this->chaveEscala($existente)

                ) {

                    continue;

                }



                $this->adicionarConflito(

                    $propostas,

                    $index,

                    'sobreposicao_destino',

                    sprintf(

                        'O profissional já possui a escala #%d, contrato #%d, entre %s e %s.',

                        $existente->id,

                        $existente->contract_id,

                        $existente->dataentrada,

                        $existente->datasaida

                    )

                );

            }

        }



        foreach ($propostas as $proposta) {

            if (!$proposta['conflito']) {

                continue;

            }



            $avisos[] = [

                'tipo' => 'conflito_escala',

                'escala_origem_id' => $proposta['escala_origem_id'],

                'contract_id' => $proposta['contract_id'],

                'prestador_id' => $proposta['prestador_id'],

                'dataentrada' => $proposta['dataentrada'],

                'tipos_conflito' => $proposta['tipos_conflito'],

                'mensagens' => $proposta['motivos_conflito'],

            ];

        }

    }

    private function horariosSobrepostos(

        $inicioA,

        $fimA,

        $inicioB,

        $fimB

    ): bool {

        if (

            !$inicioA ||

            !$fimA ||

            !$inicioB ||

            !$fimB

        ) {

            return false;

        }



        $inicioA = Carbon::parse($inicioA);

        $fimA = Carbon::parse($fimA);

        $inicioB = Carbon::parse($inicioB);

        $fimB = Carbon::parse($fimB);



        return $inicioA->lessThan($fimB)

            && $inicioB->lessThan($fimA);

    }



    private function adicionarConflito(

        array &$propostas,

        int $index,

        string $tipo,

        string $mensagem

    ): void {

        $propostas[$index]['conflito'] = true;



        if (!in_array(

            $tipo,

            $propostas[$index]['tipos_conflito'],

            true

        )) {

            $propostas[$index]['tipos_conflito'][] = $tipo;

        }



        if (!in_array(

            $mensagem,

            $propostas[$index]['motivos_conflito'],

            true

        )) {

            $propostas[$index]['motivos_conflito'][] = $mensagem;

        }

    }

    private function buscarQuantidadesOrcamento(

        array $contratos

    ): Collection {

        if (empty($contratos)) {

            return collect();

        }



        $avulsos = DB::table('ml_contracts as c')

            ->join(

                'ml_budget_services as bs',

                'bs.budget_id',

                '=',

                'c.budget_id'

            )

            ->where('c.company_id', $this->empresaId())

            ->whereIn('c.id', $contratos)

            ->whereNull('bs.deleted_at')

            ->select([

                'c.id as contract_id',

                'bs.servico_id',

                'bs.quantity',

                'bs.frequency',

                'bs.week_days',

                'bs.id as origem_id',

            ])

            ->selectRaw("'budget_service' as origem")

            ->get();



        $personalizados = DB::table('ml_contracts as c')

            ->join(

                'ml_package_custom as pc',

                'pc.budget_id',

                '=',

                'c.budget_id'

            )

            ->join(

                'ml_packages_custom_services as ps',

                'ps.ml_package_custom_id',

                '=',

                'pc.id'

            )

            ->where('c.company_id', $this->empresaId())

            ->whereIn('c.id', $contratos)

            ->whereNull('pc.deleted_at')

            ->whereNull('ps.deleted_at')

            ->select([

                'c.id as contract_id',

                'ps.servico_id',

                'ps.quantity',

                'ps.frequency',

                'ps.week_days',

                'ps.id as origem_id',

            ])

            ->selectRaw("'package_custom' as origem")

            ->get();



        return $avulsos->concat($personalizados);

    }



    private function compararOrcamento(

        array $propostas,

        Collection $orcamentos

    ): array {

        $propostasPorServico = collect($propostas)

            ->groupBy(function ($escala) {

                return $escala['contract_id'] . ':' .

                    $escala['servico_id'];

            });



        $orcamentoPorServico = $orcamentos

            ->groupBy(function ($item) {

                return $item->contract_id . ':' .

                    $item->servico_id;

            });



        $chaves = $propostasPorServico->keys();



        $resultado = [];



        foreach ($chaves as $chave) {

            [$contratoId, $servicoId] = explode(':', $chave);



            $itens = $propostasPorServico->get(

                $chave,

                collect()

            );



            $itensOrcamento = $orcamentoPorServico->get(

                $chave,

                collect()

            );



            $quantidade = $itensOrcamento->sum(function ($item) {

                return (int) $item->quantity;

            });



            $frequencias = $itensOrcamento

                ->pluck('frequency')

                ->filter()

                ->unique()

                ->values()

                ->all();



            $referenciaMensal = !empty($frequencias) &&

                collect($frequencias)->every(function ($frequencia) {

                    return mb_strtolower(trim($frequencia)) ===

                        'mensal';

                });



            $resultado[] = [

                'contract_id' => (int) $contratoId,

                'servico_id' => (int) $servicoId,

                'servico' => $itens->first()['servico'] ?? null,

                'quantidade_prevista' =>

                $itensOrcamento->isEmpty()

                    ? null

                    : $quantidade,

                'status_orcamento' => $itensOrcamento->isEmpty()

                    ? 'sem_previsao'

                    : 'encontrado',

                'quantidade_proposta' => $itens->count(),

                'comparacao_mensal_disponivel' =>

                $referenciaMensal,

                'diferenca' => $referenciaMensal

                    ? $quantidade - $itens->count()

                    : null,

                'frequencias' => $frequencias,

                'origens_orcamento' => $itensOrcamento

                    ->map(function ($item) {

                        return [

                            'origem' => $item->origem,

                            'origem_id' => $item->origem_id,

                            'quantidade' => $item->quantity,

                            'frequency' => $item->frequency,

                            'week_days' =>

                            $this->normalizarDiasSemana(

                                $item->week_days

                            ),

                        ];

                    })

                    ->values()

                    ->all(),

            ];

        }



        return $resultado;

    }



    private function normalizarDiasSemana($valor): array

    {

        if (empty($valor)) {

            return [];

        }



        if (is_array($valor)) {

            return $valor;

        }



        $decodificado = json_decode($valor, true);



        if (is_array($decodificado)) {

            return $decodificado;

        }



        return array_values(array_filter(array_map(

            'trim',

            explode(',', trim((string) $valor, '"'))

        )));

    }



    private function adicionarAvisosOrcamento(

        array $servicos,

        array &$avisos

    ): void {

        foreach ($servicos as $servico) {

            if ($servico['status_orcamento'] === 'sem_previsao') {

                $avisos[] = [

                    'tipo' => 'servico_sem_previsao',

                    'contract_id' => $servico['contract_id'],

                    'servico_id' => $servico['servico_id'],

                    'mensagem' =>

                    'Existem escalas para este serviço, mas não foi ' .

                        'localizada uma previsão ativa no orçamento.'

                ];



                continue;

            }

            if (!$servico['comparacao_mensal_disponivel']) {

                $avisos[] = [

                    'tipo' => 'previsao_nao_comparavel',

                    'contract_id' => $servico['contract_id'],

                    'servico_id' => $servico['servico_id'],

                    'mensagem' =>

                    'A frequência não possui uma referência ' .

                        'mensal confirmada para comparação.',

                ];



                continue;

            }



            $diferenca = $servico['diferenca'];



            if ($diferenca === 0) {

                continue;

            }



            $avisos[] = [

                'tipo' => 'divergencia_orcamento',

                'contract_id' => $servico['contract_id'],

                'servico_id' => $servico['servico_id'],

                'diferenca' => $diferenca,

                'mensagem' => $diferenca > 0

                    ? "Faltam {$diferenca} escala(s) para a previsão."

                    : 'A proposta supera a quantidade prevista em ' .

                    abs($diferenca) . ' escala(s).',

            ];

        }

    }



    public function ajustarAutomaticamente(array $dados): array

    {

        $preview = $this->preview($dados);



        $propostas = $preview['propostas'];

        $destino = $this->obterMes($preview['mes_destino']);



        $existentes = $this->buscarEscalasDestino($destino);



        $datasReservadas = [];

        $movimentadas = [];

        $naoResolvidas = [];

        foreach ($propostas as $proposta) {

            if (empty($proposta['conflito'])) {

                $datasReservadas[] = $proposta;

            }

        }



        foreach ($propostas as $indice => $proposta) {

            if (empty($proposta['conflito'])) {

                continue;

            }



            $entradaOriginal = Carbon::parse(

                $proposta['dataentrada']

            );



            $saidaOriginal = Carbon::parse(

                $proposta['datasaida']

            );



            $duracaoSegundos = $entradaOriginal

                ->diffInSeconds($saidaOriginal);



            $dataEncontrada = null;



            $candidatos = $this->gerarDatasCandidatas(

                $entradaOriginal,

                $destino

            );



            foreach ($candidatos as $candidato) {

                $novaEntrada = $candidato->copy();



                $novaSaida = $novaEntrada->copy()

                    ->addSeconds($duracaoSegundos);



                $teste = $proposta;



                $teste['dataentrada'] =

                    $novaEntrada->format('Y-m-d H:i:s');



                $teste['datasaida'] =

                    $novaSaida->format('Y-m-d H:i:s');



                $teste['horaentrada'] =

                    $novaEntrada->format('H:i');



                $teste['horasaida'] =

                    $novaSaida->format('H:i');



                if ($this->possuiConflitoParaAjuste(

                    $teste,

                    $datasReservadas,

                    $existentes

                )) {

                    continue;

                }



                $dataEncontrada = $teste;

                break;

            }



            if ($dataEncontrada === null) {

                $datasReservadas[] = $proposta;



                $naoResolvidas[] = [

                    'escala_origem_id' =>

                    $proposta['escala_origem_id'],

                    'mensagem' =>

                    'Não foi encontrada uma data livre ' .

                        'para esta escala no mês de destino.',

                ];



                continue;

            }



            $mudouData = $dataEncontrada['dataentrada']

                !== $proposta['dataentrada'];



            $propostas[$indice] = $dataEncontrada;

            $datasReservadas[] = $dataEncontrada;



            if ($mudouData) {

                $movimentadas[] = [

                    'escala_origem_id' =>

                    $proposta['escala_origem_id'],

                    'contract_id' => $proposta['contract_id'],

                    'prestador_id' => $proposta['prestador_id'],

                    'data_anterior' => $proposta['dataentrada'],

                    'data_nova' =>

                    $dataEncontrada['dataentrada'],

                ];

            }

        }



        $avisos = array_values(array_filter(

            $preview['avisos'],

            function ($aviso) {

                return ($aviso['tipo'] ?? null)

                    !== 'conflito_escala';

            }

        ));



        $this->identificarDuplicidades(

            $propostas,

            $existentes,

            $avisos

        );



        foreach ($naoResolvidas as $item) {

            $avisos[] = [

                'tipo' => 'ajuste_nao_resolvido',

                'escala_origem_id' =>

                $item['escala_origem_id'],

                'mensagem' => $item['mensagem'],

            ];

        }



        $preview['propostas'] = $propostas;



        $preview['calendario'] = collect($propostas)

            ->sortBy('dataentrada')

            ->groupBy(function ($item) {

                return substr($item['dataentrada'], 0, 10);

            })

            ->map(function ($itens, $data) {

                return [

                    'data' => $data,

                    'quantidade' => $itens->count(),

                    'escalas' => $itens->values()->all(),

                ];

            })

            ->values()

            ->all();



        $preview['resumo']['escalas_propostas'] =

            count($propostas);



        $preview['resumo']['conflitos'] =

            collect($propostas)

            ->where('conflito', true)

            ->count();



        $preview['resumo']['movimentadas'] =

            count($movimentadas);



        $preview['resumo']['nao_resolvidas'] =

            count($naoResolvidas);



        $preview['modo_distribuicao'] =

            'ajuste_automatico_conflitos';



        $preview['ajustes_realizados'] = $movimentadas;

        $preview['avisos'] = $avisos;



        return $preview;

    }



    private function gerarDatasCandidatas(

        Carbon $entradaOriginal,

        Carbon $destino

    ): array {

        $datas = [];



        $dataReferencia = $entradaOriginal->copy()->startOfDay();



        for ($dia = 1; $dia <= $destino->daysInMonth; $dia++) {

            $data = $destino->copy()

                ->day($dia)

                ->setTime(

                    $entradaOriginal->hour,

                    $entradaOriginal->minute,

                    $entradaOriginal->second

                );



            $distancia = abs(

                $data->copy()

                    ->startOfDay()

                    ->diffInDays($dataReferencia)

            );



            $mesmoDiaSemana =

                $data->dayOfWeek === $entradaOriginal->dayOfWeek;



            $datas[] = [

                'data' => $data,

                'distancia' => $distancia,

                'mesmo_dia_semana' => $mesmoDiaSemana,

            ];

        }



        usort($datas, function ($a, $b) {

            if ($a['distancia'] != $b['distancia']) {

                return $a['distancia'] <=> $b['distancia'];

            }



            if (

                $a['mesmo_dia_semana'] !==

                $b['mesmo_dia_semana']

            ) {

                return $a['mesmo_dia_semana'] ? -1 : 1;

            }



            return strcmp(

                $a['data']->format('Y-m-d'),

                $b['data']->format('Y-m-d')

            );

        });



        return array_map(function ($item) {

            return $item['data'];

        }, $datas);

    }



    private function possuiConflitoParaAjuste(

        array $candidata,

        array $reservadas,

        Collection $existentes

    ): bool {

        foreach ($reservadas as $reservada) {

            if (

                $this->chaveEscala($candidata) ===

                $this->chaveEscala($reservada)

            ) {

                return true;

            }



            if (

                !$this->mesmoProfissional(

                    $candidata['prestador_id'] ?? null,

                    $reservada['prestador_id'] ?? null

                )

            ) {

                continue;

            }



            if ($this->horariosSobrepostos(

                $candidata['dataentrada'],

                $candidata['datasaida'],

                $reservada['dataentrada'],

                $reservada['datasaida']

            )) {

                return true;

            }

        }



        foreach ($existentes as $existente) {

            if (

                $this->chaveEscala($candidata) ===

                $this->chaveEscala($existente)

            ) {

                return true;

            }



            if (

                !$this->mesmoProfissional(

                    $candidata['prestador_id'] ?? null,

                    $existente->prestador_id

                )

            ) {

                continue;

            }



            if ($this->horariosSobrepostos(

                $candidata['dataentrada'],

                $candidata['datasaida'],

                $existente->dataentrada,

                $existente->datasaida

            )) {

                return true;

            }

        }



        return false;

    }



    private function mesmoProfissional($primeiro, $segundo): bool

    {

        return $primeiro !== null

            && $segundo !== null

            && (int) $primeiro > 0

            && (int) $primeiro === (int) $segundo;

    }


    /**
     * Persiste exclusivamente as propostas aprovadas pelo usuário.
     * Avisos de orçamento não impedem a confirmação, mediante aceite explícito.
     */
    /** Histórico de operações concluídas para a empresa autenticada. */
    public function historico(array $filtros = []): array
    {
        $empresaId = $this->empresaId();
        $porPagina = min(50, max(1, (int) ($filtros['per_page'] ?? 10)));

        $consulta = DB::table('ml_scale_clone_operations as op')
            ->leftJoin('pessoas as p', 'p.id', '=', 'op.pessoa_id')
            ->where('op.company_id', $empresaId)
            ->select('op.id', 'op.pessoa_id', 'p.nome as pessoa_nome',
                'op.created_at', 'op.result_json');

        if (!empty($filtros['pessoa'])) {
            $nome = trim($filtros['pessoa']);
            $consulta->where('p.nome', 'like', '%' . $nome . '%');
        }
        if (!empty($filtros['data_inicio'])) {
            $consulta->whereDate('op.created_at', '>=', $filtros['data_inicio']);
        }
        if (!empty($filtros['data_fim'])) {
            $consulta->whereDate('op.created_at', '<=', $filtros['data_fim']);
        }

        $pagina = $consulta->orderByDesc('op.id')->paginate($porPagina);
        $registros = collect($pagina->items())->map(function ($item) {
            $resultado = json_decode($item->result_json, true);
            if (!is_array($resultado)) $resultado = [];
            return [
                'id' => (int) $item->id,
                'pessoa_id' => $item->pessoa_id === null ? null : (int) $item->pessoa_id,
                'pessoa_nome' => $item->pessoa_nome ?: 'Não identificado',
                'created_at' => $item->created_at,
                'mes_origem' => $resultado['mes_origem'] ?? null,
                'mes_destino' => $resultado['mes_destino'] ?? null,
                'escalas_criadas' => (int) ($resultado['escalas_criadas'] ?? 0),
                'avisos_orcamento_aceitos' => (bool) ($resultado['avisos_orcamento_aceitos'] ?? false),
                'escalas' => $resultado['escalas'] ?? [],
            ];
        })->all();

        return [
            'registros' => $registros,
            'pagina_atual' => $pagina->currentPage(),
            'ultima_pagina' => $pagina->lastPage(),
            'total' => $pagina->total(),
            'por_pagina' => $pagina->perPage(),
        ];
    }

    public function confirmar(array $dados): array
    {
        $empresaId = $this->empresaId();
        $pessoaId = (int) (auth()->user()->pessoa->id ?? 0);
        if ($pessoaId <= 0) {
            throw new InvalidArgumentException('Pessoa responsável pela clonagem não identificada.');
        }
        $origem = $this->obterMes($dados['mes_origem']);
        $destino = $this->obterMes($dados['mes_destino']);

        if (!$destino->isSameMonth($origem->copy()->addMonthNoOverflow())) {
            throw new InvalidArgumentException('O destino deve ser o mês seguinte à origem.');
        }

        if (empty($dados['aceitar_avisos_orcamento'])) {
            throw new InvalidArgumentException('É necessário aceitar os avisos de orçamento.');
        }

        $enviadas = $dados['propostas'];
        $ids = array_map(function ($p) {
            return (int) $p['escala_origem_id'];
        }, $enviadas);

        if (count($ids) !== count(array_unique($ids))) {
            throw new InvalidArgumentException('Uma mesma escala de origem foi enviada mais de uma vez.');
        }

        // Recalcula o escopo autorizado. Não recalcula as datas do ajuste.
        $previa = $this->preview($dados);
        $idsPermitidos = collect($previa['propostas'])
            ->pluck('escala_origem_id')->map(function ($id) { return (int) $id; })
            ->sort()->values()->all();
        $idsRecebidos = $ids;
        sort($idsRecebidos);

        if ($idsPermitidos !== $idsRecebidos || empty($idsPermitidos)) {
            throw new InvalidArgumentException(
                'A seleção difere da prévia atual. Atualize a prévia antes de confirmar.'
            );
        }

        $referencias = collect($previa['propostas'])->keyBy('escala_origem_id');
        $propostas = [];
        foreach ($enviadas as $item) {
            $id = (int) $item['escala_origem_id'];
            $referencia = $referencias->get($id);
            $entrada = Carbon::createFromFormat('!Y-m-d H:i:s', $item['dataentrada']);
            $saida = Carbon::createFromFormat('!Y-m-d H:i:s', $item['datasaida']);
            if (!$entrada || !$saida || !$entrada->isSameMonth($destino)) {
                throw new InvalidArgumentException('Data fora do mês de destino.');
            }
            $duracaoProposta = $entrada->diffInSeconds($saida, false);
            $duracaoOriginal = Carbon::parse($referencia['dataentrada'])
                ->diffInSeconds(Carbon::parse($referencia['datasaida']), false);
            if ($duracaoProposta <= 0 || $duracaoProposta !== $duracaoOriginal ||
                $entrada->format('H:i:s') !== substr($referencia['dataentrada'], 11, 8)) {
                throw new InvalidArgumentException(
                    'Uma proposta alterou a duração ou o horário do atendimento.'
                );
            }
            $proposta = $referencia;
            $proposta['dataentrada'] = $entrada->format('Y-m-d H:i:s');
            $proposta['datasaida'] = $saida->format('Y-m-d H:i:s');
            $proposta['horaentrada'] = $entrada->format('H:i');
            $proposta['horasaida'] = $saida->format('H:i');
            $propostas[] = $proposta;
        }

        $chave = $dados['idempotency_key'];
        $hash = hash('sha256', json_encode([
            $empresaId, $dados['mes_origem'], $dados['mes_destino'],
            $dados['modalidade'], $dados['contract_id'] ?? null,
            $dados['filtros'] ?? [], $enviadas
        ], JSON_UNESCAPED_UNICODE));
        $nomeLock = 'clone-scale:' . $empresaId . ':' . $destino->format('Ym');
        $lock = DB::selectOne('SELECT GET_LOCK(?, 15) AS adquirido', [$nomeLock]);
        if (!$lock || (int) $lock->adquirido !== 1) {
            throw new InvalidArgumentException('Outra clonagem está em andamento. Tente novamente.');
        }

        try {
            return DB::transaction(function () use (
                $empresaId, $pessoaId, $origem, $destino, $chave, $hash, $propostas, $ids
            ) {
                // Necessário criar a tabela pela migration fornecida.
                $anterior = DB::table('ml_scale_clone_operations')
                    ->where('company_id', $empresaId)
                    ->where('idempotency_key', $chave)
                    ->lockForUpdate()->first();
                if ($anterior) {
                    if ($anterior->payload_hash !== $hash) {
                        throw new InvalidArgumentException(
                            'Esta chave de operação já foi usada para outra solicitação.'
                        );
                    }
                    return json_decode($anterior->result_json, true);
                }

                $originais = DB::table('escalas as e')
                    ->join('ml_contracts as c', 'c.id', '=', 'e.contract_id')
                    ->where('e.empresa_id', $empresaId)
                    ->where('c.company_id', $empresaId)
                    ->where('e.ativo', 1)
                    ->where('c.active', 1)
                    ->whereIn('e.id', $ids)
                    ->select('e.*')
                    ->lockForUpdate()->get()->keyBy('id');

                if ($originais->count() !== count($ids)) {
                    throw new InvalidArgumentException(
                        'Escala ou contrato de origem não está mais ativo. Atualize a prévia.'
                    );
                }

                foreach ($originais as $original) {
                    if (!Carbon::parse($original->dataentrada)->isSameMonth($origem)) {
                        throw new InvalidArgumentException('Uma escala não pertence ao mês de origem.');
                    }
                }

                $existentes = $this->buscarEscalasDestino($destino);
                $avisos = [];
                $this->identificarDuplicidades($propostas, $existentes, $avisos);
                if (collect($propostas)->contains(function ($p) {
                    return !empty($p['conflito']);
                })) {
                    throw new InvalidArgumentException(
                        'Existem conflitos ou duplicidades no destino. Revise a prévia.'
                    );
                }

                $agora = now();
                $colunas = array_flip(\Illuminate\Support\Facades\Schema::getColumnListing('escalas'));
                $camposPermitidos = [
                    'ordemservico_id', 'contract_id', 'paciente_id',
                    'prestador_proprietario', 'prestador_id', 'cooperative_id',
                    'servico_id', 'service_value', 'tipo_ajuste', 'valor_ajuste',
                    'valor_total', 'formacao_id', 'periodo', 'observacao',
                    'tipo', 'editavel'
                ];
                $criados = [];

                foreach ($propostas as $p) {
                    $modelo = $originais->get((int) $p['escala_origem_id']);
                    $insert = ['empresa_id' => $empresaId];
                    foreach ($camposPermitidos as $campo) {
                        if (isset($colunas[$campo])) {
                            $insert[$campo] = $modelo->{$campo} ?? null;
                        }
                    }
                    $insert['dataentrada'] = $p['dataentrada'];
                    $insert['datasaida'] = $p['datasaida'];
                    $insert['horaentrada'] = $p['horaentrada'];
                    $insert['horasaida'] = $p['horasaida'];
                    $insert['status'] = 0;
                    $insert['folga'] = 0;
                    $insert['substituto'] = null;
                    $insert['ativo'] = 1;
                    $insert['created_at'] = $agora;
                    $insert['updated_at'] = $agora;
                    if (isset($colunas['is_evolution'])) $insert['is_evolution'] = 0;

                    $novoId = DB::table('escalas')->insertGetId($insert);
                    $criados[] = ['escala_origem_id' => (int) $modelo->id,
                        'escala_id' => (int) $novoId,
                        'dataentrada' => $p['dataentrada']];

                    // Copia o modelo de cuidados com o mesmo comportamento do fluxo antigo.
                    $cuidados = \App\Models\Api_V2_0\CuidadoEscala::where('escala_id', $modelo->id)->get();
                    foreach ($cuidados as $cuidado) {
                        \App\Models\Api_V2_0\CuidadoEscala::create([
                            'escala_id' => $novoId,
                            'cuidado_id' => $cuidado->cuidado_id,
                            'data' => null,
                            'hora' => null,
                            'status' => false
                        ]);
                    }
                }

                $resultado = [
                    'mes_origem' => $origem->format('Y-m'),
                    'mes_destino' => $destino->format('Y-m'),
                    'escalas_criadas' => count($criados),
                    'escalas' => $criados,
                    'avisos_orcamento_aceitos' => true,
                ];
                DB::table('ml_scale_clone_operations')->insert([
                    'company_id' => $empresaId,
                    'pessoa_id' => $pessoaId,
                    'idempotency_key' => $chave,
                    'payload_hash' => $hash,
                    'result_json' => json_encode($resultado, JSON_UNESCAPED_UNICODE),
                    'created_at' => $agora,
                    'updated_at' => $agora,
                ]);
                return $resultado;
            }, 3);
        } finally {
            DB::select('SELECT RELEASE_LOCK(?)', [$nomeLock]);
        }
    }

}
