import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { EscalaService } from 'src/app/services/operacao/escala.service';

@Component({
  selector: 'app-historico-clonagens',
  templateUrl: './historico-clonagens.component.html',
  styleUrls: ['./historico-clonagens.component.css']
})
export class HistoricoClonagensComponent implements OnInit, OnDestroy {
  carregando = false;
  erro = '';
  registros: any[] = [];
  paginaAtual = 1;
  ultimaPagina = 1;
  total = 0;
  pessoa = '';
  dataInicio = '';
  dataFim = '';
  selecionado: any = null;
  private req?: Subscription;

  constructor(
    private escalaService: EscalaService,
    private dialogRef: MatDialogRef<HistoricoClonagensComponent>
  ) {}

  ngOnInit(): void { this.carregar(1); }

  carregar(pagina: number): void {
    if (this.carregando || pagina < 1 || pagina > this.ultimaPagina && pagina !== 1) return;
    this.carregando = true;
    this.erro = '';
    this.req = this.escalaService.listarHistoricoClonagens({
      page: pagina,
      per_page: 10,
      pessoa: this.pessoa.trim(),
      data_inicio: this.dataInicio || undefined,
      data_fim: this.dataFim || undefined
    }).pipe(finalize(() => this.carregando = false)).subscribe({
      next: (res: any) => {
        if (!res || !res.status || !res.data) {
          this.erro = res && res.message || 'Não foi possível carregar o histórico.';
          return;
        }
        this.registros = res.data.registros || [];
        this.paginaAtual = res.data.pagina_atual || 1;
        this.ultimaPagina = res.data.ultima_pagina || 1;
        this.total = res.data.total || 0;
        this.selecionado = null;
      },
      error: (e: any) => {
        this.erro = e && e.error && e.error.message || 'Erro ao consultar histórico.';
      }
    });
  }

  pesquisar(): void { this.carregar(1); }
  limpar(): void {
    this.pessoa = '';
    this.dataInicio = '';
    this.dataFim = '';
    this.carregar(1);
  }
  verDetalhes(registro: any): void {
    this.selecionado = this.selecionado && this.selecionado.id === registro.id
      ? null : registro;
  }
  fechar(): void { this.dialogRef.close(); }
  trackById(_index: number, item: any): number { return item.id; }
  ngOnDestroy(): void { if (this.req) this.req.unsubscribe(); }
}
