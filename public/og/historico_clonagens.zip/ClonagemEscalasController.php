<?php

namespace App\Http\Controllers\Api_V2_0;

use App\Http\Controllers\Controller;
use App\Services\ClonagemEscalasService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use InvalidArgumentException;
use Throwable;

class ClonagemEscalasController extends Controller
{
    private function regrasBase(): array
    {
        return [
            'mes_origem' => ['required', 'date_format:Y-m'],
            'mes_destino' => ['nullable', 'date_format:Y-m'],
            'modalidade' => ['required', 'in:enfermagem,multi,todos'],
            'contract_id' => ['nullable', 'integer', 'min:1'],
            'filtros' => ['nullable', 'array'],
            'filtros.busca' => ['nullable', 'string', 'max:255'],
            'filtros.servico' => ['nullable', 'string'],
            'filtros.periodo' => ['nullable', 'string'],
            'filtros.tipo' => ['nullable', 'string'],
            'filtros.situacao' => ['nullable', 'in:normal,folga,internado'],
        ];
    }

    private function executar(Request $request, ClonagemEscalasService $service, string $acao)
    {
        $regras = $this->regrasBase();
        if ($acao === 'confirmar') {
            $regras['mes_destino'] = ['required', 'date_format:Y-m'];
            $regras['idempotency_key'] = ['required', 'uuid'];
            $regras['aceitar_avisos_orcamento'] = ['required', 'accepted'];
            $regras['propostas'] = ['required', 'array', 'min:1', 'max:2000'];
            $regras['propostas.*.escala_origem_id'] = ['required', 'integer', 'min:1'];
            $regras['propostas.*.dataentrada'] = ['required', 'date_format:Y-m-d H:i:s'];
            $regras['propostas.*.datasaida'] = ['required', 'date_format:Y-m-d H:i:s'];
        }
        $validator = Validator::make($request->all(), $regras);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Dados inválidos.',
                'errors' => $validator->errors(),
            ], 422);
        }

        try {
            $validado = $validator->validated();
            if ($acao === 'preview') {
                $resultado = $service->preview($validado);
                $mensagem = 'Prévia gerada com sucesso.';
            } elseif ($acao === 'ajustar') {
                $resultado = $service->ajustarAutomaticamente($validado);
                $mensagem = 'Ajuste automático calculado com sucesso.';
            } else {
                $resultado = $service->confirmar($validado);
                $mensagem = 'Clonagem confirmada com sucesso.';
            }
            return response()->json([
                'status' => true,
                'message' => $mensagem,
                'data' => $resultado,
            ]);
        } catch (InvalidArgumentException $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
            ], 422);
        } catch (Throwable $e) {
            Log::error('CLONAGEM_ESCALAS_' . strtoupper($acao) . '_ERRO', [
                'message' => $e->getMessage(),
                'line' => $e->getLine(),
            ]);
            return response()->json([
                'status' => false,
                'message' => 'Não foi possível executar a operação de clonagem.',
            ], 500);
        }
    }

    public function preview(Request $request, ClonagemEscalasService $service)
    {
        return $this->executar($request, $service, 'preview');
    }

    public function ajustar(Request $request, ClonagemEscalasService $service)
    {
        return $this->executar($request, $service, 'ajustar');
    }

    public function confirmar(Request $request, ClonagemEscalasService $service)
    {
        return $this->executar($request, $service, 'confirmar');
    }
    public function historico(Request $request, ClonagemEscalasService $service)
    {
        $validator = Validator::make($request->all(), [
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:50'],
            'pessoa' => ['nullable', 'string', 'max:120'],
            'data_inicio' => ['nullable', 'date_format:Y-m-d'],
            'data_fim' => ['nullable', 'date_format:Y-m-d', 'after_or_equal:data_inicio'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Filtros inválidos.',
                'errors' => $validator->errors(),
            ], 422);
        }

        try {
            return response()->json([
                'status' => true,
                'data' => $service->historico($validator->validated()),
            ]);
        } catch (InvalidArgumentException $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
            ], 422);
        } catch (Throwable $e) {
            Log::error('CLONAGEM_ESCALAS_HISTORICO_ERRO', [
                'message' => $e->getMessage(),
                'line' => $e->getLine(),
            ]);
            return response()->json([
                'status' => false,
                'message' => 'Não foi possível consultar o histórico.',
            ], 500);
        }
    }
}
