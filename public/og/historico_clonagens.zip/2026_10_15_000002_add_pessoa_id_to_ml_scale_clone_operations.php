<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasColumn('ml_scale_clone_operations', 'pessoa_id')) {
            Schema::table('ml_scale_clone_operations', function (Blueprint $table) {
                // Nullable para preservar histórico de operações anteriores.
                $table->unsignedBigInteger('pessoa_id')->nullable()->after('company_id');
                $table->index('pessoa_id', 'clone_ops_pessoa_idx');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('ml_scale_clone_operations', 'pessoa_id')) {
            Schema::table('ml_scale_clone_operations', function (Blueprint $table) {
                $table->dropIndex('clone_ops_pessoa_idx');
                $table->dropColumn('pessoa_id');
            });
        }
    }
};
